declare module "*.mp4" {
  const src: string;
  export default src;
}